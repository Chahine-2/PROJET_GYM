#include <gtk/gtk.h>

void on_button1_clicked (GtkButton *button, gpointer user_data);
void on_button2_clicked (GtkButton *button, gpointer user_data);
void on_button10_clicked (GtkButton *button, gpointer user_data);
void on_button4_clicked (GtkButton *button, gpointer user_data);
void on_button3_clicked (GtkButton *button, gpointer user_data);
void on_button5_clicked (GtkButton *button, gpointer user_data);
void on_button13_clicked (GtkButton *button, gpointer user_data);
void on_button12_clicked (GtkButton *button, gpointer user_data);
void on_button11_clicked (GtkButton *button, gpointer user_data);
void on_button6_clicked (GtkButton *button, gpointer user_data);
void on_button7_clicked (GtkButton *button, gpointer user_data);
void on_button8_clicked (GtkButton *button, gpointer user_data);
void on_button9_clicked (GtkButton *button, gpointer user_data);
void on_button14_clicked (GtkButton *button, gpointer user_data);
void on_button15_clicked (GtkButton *button, gpointer user_data);
void on_button17_clicked (GtkButton *button, gpointer user_data);
void on_button19_clicked (GtkButton *button, gpointer user_data);
void on_button20_clicked (GtkButton *button, gpointer user_data);
void on_button16_clicked (GtkButton *button, gpointer user_data);
void on_button30_clicked (GtkButton *button, gpointer user_data);

// New Coach Buttons
void on_button_ajouter_coach_clicked (GtkButton *button, gpointer user_data);
void on_button_modifier_coach_clicked (GtkButton *button, gpointer user_data);
void on_button_supprimer_coach_clicked (GtkButton *button, gpointer user_data);
void on_button_rechercher_coach_clicked (GtkButton *button, gpointer user_data);
